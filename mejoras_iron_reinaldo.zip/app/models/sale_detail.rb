class SaleDetail < ApplicationRecord
	belongs_to :sale
	belongs_to :item
	has_many  :movements
	has_many :devolutions
	validates :item_id, presence: true
	validates :qty, presence: true
	validates :price, presence: true
	validates :discount, presence: true

  before_save :validate_discount_rules

  private

  def validate_discount_rules
    if self.item && !self.item.todiscount
      self.todiscount = false
      self.discount = 0.0
      self.price_sale = self.price
    elsif self.item && self.item.todiscount
      self.todiscount = true
    end
  end

  public

	accepts_nested_attributes_for :item

	def subtotal
		self.qty ? ((self.qty.to_i - qty_devolutions.to_i) * price_sale.to_f ).round(4) : 0
	end
	def sTotal
		self.qty ? ((self.qty.to_i - qty_devolutions.to_i) * price.to_f ).round(4) : 0
	end

	def unit_price
		if persisted?
			price
		else
			item ? item.price : 0
		end
	end
	def get_discount
		if self.item.todiscount
			self.qty ? ((qty * unit_price)*getTotalDiscount)/100 : 0
		else
		res  =	0
		end
		
	end
	def price_select
		
	end
	def current_available_credit
		total = self.sale.client.line_credit_available
		current_price_item = self.subtotal
		res = total+current_price_item

	end
	def qty_devolutions
		devolutions = self.devolutions
		total = 0
			devolutions.flat_map do |d|
				total += d.qty.to_i
			end
		total
	end
	def get_qty_total
		total = self.qty.to_i - self.qty_devolutions.to_i
	end
	def getTotalDiscount
		res = 0
		res = discount

	end
	def getTotalSaleDetailsAmounto
		total = self.qty.to_i * price_sale.to_f
		dis = 1 - (self.sale.discount.to_f / 100)
		if self.todiscount
			total = total * dis
		end
		total
	end

	def dispatch_instructions
		# Obtener movimientos de este detalle
		instructions = []
		self.movements.each do |m|
			stock = m.stock
			next unless stock
			
			qty = m.qty_out.to_i
			# Si el lote tiene una presentación asignada, la priorizamos para el cálculo
			lote_pres = stock.presentation
			
			if lote_pres && lote_pres.qty.to_i > 0
				# Si el lote "sabe" quién es (ej. Caja 1200), forzamos el desglose empezando por esa presentación
				num_main = (qty / lote_pres.qty.to_i)
				remainder = qty % lote_pres.qty.to_i
				
				instructions << "#{num_main} [#{lote_pres.name}]" if num_main > 0
				
				if remainder > 0
					# Desglosamos el resto con las demás presentaciones disponibles del item
					instructions << format_qty_with_presentations(remainder, self.item, exclude_id: lote_pres.id)
				end
			else
				# Si el lote es anónimo, intentamos desglosarlo con cualquier presentación del item
				instructions << format_qty_with_presentations(qty, self.item)
			end
		end
		instructions.join(" + ")
	end

	private

	def format_qty_with_presentations(total_qty, item, exclude_id: nil)
		qty_val = total_qty.to_i
		return "#{qty_val} pzs" if qty_val <= 0 || item.nil?
		
		# Buscar presentaciones del item de mayor a menor (ej. Caja -> Paquete)
		query = item.presentations.where("qty > 0").order(qty: :desc)
		query = query.where.not(id: exclude_id) if exclude_id
		
		available_pres = query.to_a
		return "#{qty_val} pzs" if available_pres.empty?

		parts = []
		remaining = qty_val

		available_pres.each do |pres|
			pres_qty = pres.qty.to_i
			next if pres_qty == 0
			
			num = (remaining / pres_qty)
			if num > 0
				parts << "#{num} [#{pres.name}]"
				remaining %= pres_qty
			end
		end

		parts << "#{remaining} pzs" if remaining > 0
		parts.join(" + ")
	end
	
	after_save :update_sale_status_priority
	after_destroy :update_sale_status_priority
  
	private
  
	def update_sale_status_priority
	  self.sale.update_status_priority!
	end
end
